sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"ui/ui/supporters/Utility",
	"ui/ui/formatter/Formatter"
	// "ui/ui/supporters/Constants"
], function(Controller, Utility,formatter) { //Constants
	"use strict";
	
	return Controller.extend("ui.ui.controller.XOXO", {
		formatter:formatter,
		constructor: function() {
			this.utility = new Utility();
		},
		onInit: function() {
			
			this.oModel = new sap.ui.model.json.JSONModel();
			this.oModel.setData({
				"GetHospitalData":{
					"branches":[
						{"branchID":"1","branchName":"XOXO Charity Hospital","branchLocation":"Whitefield"},
						{"branchID":"2","branchName":"XOXO Star Hospital","branchLocation":"Indiranagar"},
						{"branchID":"3","branchName":"XOXO Civilian Hospital","branchLocation":"Devanahalli"}
						]
				}
			});
			this.getView().setModel(this.oModel);
			this.getView().getDetailPage().getContent()[0].getItems()[0].setModel(this.oModel);
			this.bExpanded = true;
		},
		onBeforeRendering: function() {
			if (!this.sideList) {
				var splitApp = sap.ui.getCore().byId("splitApp");
				this.sideList = splitApp.getCurrentMasterPage().getContent()[0];
				//adjust width to accomdate side bars
				sap.ui.getCore().byId("__app0-Master").setWidth("3.5%");
				sap.ui.getCore().byId("__app0-Detail").setWidth("96.5%");
				sap.ui.getCore().byId("__app1-Master").setWidth("97%");
				sap.ui.getCore().byId("__app1-Detail").setWidth("3%");
				//setting content for main page having forms and list
				this.firstTab = splitApp.getCurrentDetailPage().getContent()[0].getItems()[0];

				if (this.oModel.getData().GetHospitalData) {
					var branchInfo = this.oModel.getData().GetHospitalData.branches,
						k = 0;
					for (var i = 0; i < branchInfo.length; i++) {
						this.sideList.addItem(new sap.tnt.NavigationListItem("mainItem" + k++, {
							text: branchInfo[i].branchName,
							icon: "sap-icon://menu2"
						}));
					}
					this.k = k;
					if (!this.oBranchContent) {
						this.oBranchContent = sap.ui.jsfragment("ui.ui.view.Branches", this);
						this.firstTab.addContent(this.oBranchContent);
					}
					var solModel = new sap.ui.model.json.JSONModel();
					var solData = this.getView().getModel().getData().GetHospitalData.branches[0];
					solModel.setData(solData);
					this.getView().setModel(solModel, "solModel");
					this.oBranchContent.setModel(solModel, "solModel");
					this.activeTab = "Branches";
				}
			}
		}
	});
});